package org.scoula.todo.exception;

public class NoSuchElementException extends Exception {
    public NoSuchElementException() {
        super("그 딴거 없다");
    }
}
