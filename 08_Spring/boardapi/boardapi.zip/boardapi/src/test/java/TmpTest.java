import org.junit.jupiter.api.Test;

public class TmpTest {


    @Test
    public void test() {
        System.out.println("zz");

    }
}
