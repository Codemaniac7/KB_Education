package org.scoula.board.domain;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BoardVO {
    private Long no; //47
    private String title; // 이미지 업로딩
    private String content; //
    private String writer;
    private Date regDate;
    private Date updateDate; //

    private List<BoardAttachmentVO> attaches;

    // <setting name="mapUnderscoreToCamelCase" value="true"/>

    // mapUnderscoreToCamelCase ->  스네이크 케이스 == 카멜 케이스

    // reg_date -> regDate
    // update_date -> updateDate


}
