package org.scoula.dto;

import lombok.Data;

@Data
public class SampleDTO {

    int age;
    String name;
}
